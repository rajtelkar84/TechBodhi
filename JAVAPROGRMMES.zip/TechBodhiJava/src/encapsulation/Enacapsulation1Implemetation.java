package encapsulation;

public class Enacapsulation1Implemetation {
	
	public static void main(String[] args) {
		
		Enacapsulation1 en = new Enacapsulation1();
		en.setName("Rajkumar");
		System.out.println(en.getName());
	}

}
