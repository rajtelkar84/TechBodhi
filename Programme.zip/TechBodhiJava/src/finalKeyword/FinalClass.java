package finalKeyword;

public final class FinalClass {

}
