package finalKeyword;

public class FinalVariable {
	
	 final int a =10;
	
	void change()
	{
	//	a=20; // can not modify as a is final
	}

}
