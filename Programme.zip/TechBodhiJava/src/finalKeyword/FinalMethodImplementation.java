package finalKeyword;

public class FinalMethodImplementation extends FinalMethod {
	
/*	void notchangable()
	{
		System.out.println("I can not change"); // final method can not be changed
	}
	
	*/

}
