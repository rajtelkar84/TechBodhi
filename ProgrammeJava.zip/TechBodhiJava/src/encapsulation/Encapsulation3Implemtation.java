package encapsulation;

public class Encapsulation3Implemtation {
	
	public static void main(String[] args) {
		
		Encapsulation3 em = new Encapsulation3();
		em.setCollege("OIST");
	}

}
