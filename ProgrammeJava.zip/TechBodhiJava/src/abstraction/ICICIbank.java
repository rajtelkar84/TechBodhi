package abstraction;

public class ICICIbank extends ReserveBank{

	@Override
	int getRateOfIntrest() {
		// TODO Auto-generated method stub
		return 5;
	}

}
