package test1;

import org.testng.annotations.Test;

public class Class1 {

	@Test
	public void firsttest() {
		System.out.println("test1");
	}

}
