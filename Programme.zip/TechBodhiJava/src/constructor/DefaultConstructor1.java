package constructor;

public class DefaultConstructor1 {
	
	DefaultConstructor1()
	{
		System.out.println("I am default constructor");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DefaultConstructor1 ds = new DefaultConstructor1();

	}

}
