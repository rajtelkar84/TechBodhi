package superKeyWord;

public class SuperMethod1 {
	
	void display()
	{
		System.out.println("Super/Parent method");
	}

}
