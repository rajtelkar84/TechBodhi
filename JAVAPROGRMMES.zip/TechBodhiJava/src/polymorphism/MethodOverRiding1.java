package polymorphism;

public class MethodOverRiding1 {
	
	int speedlimit=90;
	  void abc()
	{
	  System.out.println("child class");
	 }
	
	 

}
