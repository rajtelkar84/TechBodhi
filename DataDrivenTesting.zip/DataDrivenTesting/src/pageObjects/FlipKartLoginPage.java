package pageObjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import utility.Constants;

public class FlipKartLoginPage {

	private static WebElement element =null;
	
	public static WebElement FlipKartEmail_MobNo(WebDriver driver)
	{
		element = driver.findElement(By.xpath
				("//input[@class='_2IX_2- VJZDxU']"));
		return element;
	}
	
	public static WebElement FlipKartPassword(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//input[@class='_2IX_2- _3mctLh VJZDxU']"));
		return element;
	}
	
	public static WebElement FlipKartLoginButton(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//button[@class='_2KpZ6l _2HKlqd _3AWRsL']"));
		return element;
	}
	
	
	public static boolean loginToFlipkart(WebDriver driver,String UserName,
			String Password) throws InterruptedException
	{
		FlipKartEmail_MobNo(driver).clear();
		FlipKartEmail_MobNo(driver).sendKeys(UserName);
		FlipKartPassword(driver).clear();
		FlipKartPassword(driver).sendKeys(Password);
		FlipKartLoginButton(driver).click();
		Thread.sleep(2000);
		boolean loginbutton 
		=driver.findElements(By.xpath("//button[@class='_2KpZ6l _2HKlqd _3AWRsL']"))
				.size() > 0;
		System.out.println(loginbutton);
		
		return loginbutton;
	}
	
	
	
	
	
}
