package mainScript;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
 
@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"src/feature/input1.feature",}
		,glue={"stepdef"}
		,dryRun = false
		)
public class ScriptRunner {


}


