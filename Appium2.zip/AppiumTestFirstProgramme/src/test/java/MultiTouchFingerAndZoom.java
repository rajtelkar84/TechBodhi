import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.MultiTouchAction;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class MultiTouchFingerAndZoom {
	
	static AppiumDriver driver;


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			MulitTouchCalculator();
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			driver.findElement(By.id("android:id/button1")).click();
			
			Dimension dim= driver.manage().window().getSize();
			
			int dimWidth = dim.width;
			int dimHeight = dim.height;
			// first touch
			int firstTouchXCordinate_Start = (int)(dimWidth *.5);
			int firstTouchYCordinate_Start = (int)(dimHeight *.4);
			
			int firstTouchXCordinate_End = (int)(dimWidth *.1);
			int firstTouchYCordinate_End = (int)(dimHeight *.1);
			
			// second touch
						int secondTouchXCordinate_Start = (int)(dimWidth *.5);
						int secondTouchYCordinate_Start = (int)(dimHeight *.6);
						
						int secondTouchXCordinate_End = (int)(dimWidth *.9);
						int secondTouchYCordinate_End = (int)(dimHeight *.9);
			
			TouchAction th1 = new TouchAction(driver);
			TouchAction th2 = new TouchAction(driver);
			
			th1.longPress(PointOption.point(firstTouchXCordinate_Start,firstTouchYCordinate_Start)).
			waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2))).
			moveTo(PointOption.point(firstTouchXCordinate_End, firstTouchYCordinate_End));
			
			
			th2.longPress(PointOption.point(secondTouchXCordinate_Start, secondTouchYCordinate_Start)).
			waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2))).
			moveTo(PointOption.point(secondTouchXCordinate_End, secondTouchYCordinate_End));
			
			
			MultiTouchAction mlt = new MultiTouchAction(driver);
			mlt.add(th1).add(th2).perform();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getCause());
			System.out.println(e.getMessage());

		}


	}

	public static void MulitTouchCalculator() throws MalformedURLException
	{
		DesiredCapabilities cp = new DesiredCapabilities();
		cp.setCapability("deviceName", "Galaxy M31 s");
		cp.setCapability("udid", "RZ8N90XMSCP");
		cp.setCapability("platformName", "Android");
		cp.setCapability("platformVersion", "11");

		cp.setCapability("automationName", "UiAutomator2");
		cp.setCapability("appPackage", "com.the511plus.MultiTouchTester");
		cp.setCapability("appActivity", "com.the511plus.MultiTouchTester.MultiTouchTester");

		URL url = new URL("http://127.0.0.1:4723/wd/hub");
		driver = new AppiumDriver<MobileElement>(url,cp);

		System.out.println("Application started");


	}


}
