package tests;


import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.remote.MobileCapabilityType;

public class BaseClass {

	static AppiumDriver driver;
	@BeforeTest
	public void setup() throws Exception 
	{
		try {
		DesiredCapabilities cp = new DesiredCapabilities();
		cp.setCapability("chromedriverExecutable","C:\\Users\\telkaraj\\Desktop\\AllData_18June\\Mydocs\\TechBodhi\\File\\Chromedriver\\chromedriver_win32\\chromedriver.exe");
		cp.setCapability("deviceName", "Galaxy M31 s");
		cp.setCapability("udid", "RZ8N90XMSCP");
		cp.setCapability("platformName", "Android");
		cp.setCapability("platformVersion", "11");

		cp.setCapability("automationName", "UiAutomator2");
		cp.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");
		//cp.setCapability("appPackage", "com.sec.android.app.popupcalculator");
		//cp.setCapability("appActivity", "com.sec.android.app.popupcalculator.Calculator");
        cp.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 60);
		URL url = new URL("http://127.0.0.1:4723/wd/hub");
		driver = new AppiumDriver<MobileElement>(url,cp);
		}
		catch(Exception e)
		{
		
			System.out.println("Cause is"+e.getCause());
			System.out.println("Messge is"+e.getMessage());
			e.printStackTrace();
		}
	}
	
	
	
	@AfterTest
	public void tearDown()
	{
		driver.close();
		System.out.println("End");
	}


}
