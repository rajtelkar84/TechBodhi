package testSuite;

import org.testng.annotations.Test;

public class TestSuitClass1 {
	
	@Test
	  public void method1() {
		  System.out.println("Test1");
	  }
	
	@Test
	  public void method2() {
		  System.out.println("Test 2");
	  }

}
