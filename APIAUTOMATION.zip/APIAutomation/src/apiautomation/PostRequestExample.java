package apiautomation;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class PostRequestExample {
	
	@Test
	
	public void posttest()
	{
System.out.println("hello");
		
		RestAssured.baseURI ="https://reqres.in/api/users";
		 RequestSpecification request = RestAssured.given();
		 
		 JSONObject requestParams = new JSONObject();
		 requestParams.put("name", "Rajkumar"); 
		 requestParams.put("job", "Senior_Tech_Lead");
		 
		 request.body(requestParams.toJSONString());
		 Response response = request.post("");
		 
		 int statusCode = response.getStatusCode();
		 Assert.assertEquals(String.valueOf(statusCode), "201");
		 String successCode = response.jsonPath().get("SuccessCode");
		 System.out.println(successCode);	

	}

}
