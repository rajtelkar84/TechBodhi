package superKeyWord;

public class SuperVariable1 {
	
	String abc ="I am in Parent/Super class";

}
