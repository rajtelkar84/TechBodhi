package utility;

public class Constants {
	
	public static final String URL = "https://www.flipkart.com/";

    public static final String Path_TestData = "C:\\Users\\telkaraj\\eclipse-workspace\\DataDrivenTesting\\src\\testdata\\";

    public static final String File_TestData = "TestData.xlsx";

}
