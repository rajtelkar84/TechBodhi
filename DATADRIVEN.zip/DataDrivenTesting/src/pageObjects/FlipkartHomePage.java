package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class FlipkartHomePage {
	
	private static WebElement element = null;
	
	public static WebElement FlipkartProfile(WebDriver driver)
	{
		element = driver.findElement(By.xpath("(//div[@class='exehdJ'])[1]"));
		return element;
	}
	
	public static WebElement FlipkartLogoutButton(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//div[text()='Logout']"));
		return element;
	}
	
	public static void logOutOnFlipkart(WebDriver driver) throws InterruptedException
	{
		Actions act = new Actions(driver);
		act.moveToElement(FlipkartProfile(driver)).build().perform();
		Thread.sleep(2000);
		FlipkartLogoutButton(driver).click();
	}

}
