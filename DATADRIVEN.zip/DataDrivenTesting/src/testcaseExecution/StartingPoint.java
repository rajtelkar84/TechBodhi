package testcaseExecution;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pageObjects.FlipKartLoginPage;
import pageObjects.FlipkartHomePage;
import utility.Constants;
import utility.ExcelUtils;

public class StartingPoint {
	private static WebDriver driver = null;
	public static void main(String[] args) throws Exception {
		ExcelUtils.setExcelFile(Constants.Path_TestData + 
				Constants.File_TestData,"Sheet1");
		int excelRowCount = ExcelUtils.lastrow();
		System.out.println(excelRowCount);
		for(int i=1; i<=excelRowCount; i++)
		{			
		String sUserName = ExcelUtils.getCellData(i, 1);
		String sPassword = ExcelUtils.getCellData(i, 2);
		browserInitalization();
	    boolean loginsuccessful =FlipKartLoginPage.loginToFlipkart(driver,sUserName,sPassword);
	    if(loginsuccessful==false)
	    {
	    FlipkartHomePage.logOutOnFlipkart(driver);
	    ExcelUtils.setCellData("Pass", i, 3);
	    }
	    else
	    {
	    ExcelUtils.setCellData("Fail", i, 3);
	    }
	    System.out.println("done");
	    driver.quit();
	}
	}
	
	public static void browserInitalization()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\telkaraj\\Desktop\\AllData_18June\\Mydocs\\TechBodhi\\File\\Chromedriver\\chromedriver_win32\\chromedriver.exe");
		  driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get(Constants.URL);
	}

}
