package inhritence;

public class SingleHeritence {
	
	float salary = 80000;
	
	void abc()
	{
		System.out.println("Parent class Method");
	}
	

}
