package abstraction;

public abstract class AbstarctclassInterface implements Interface2{
	
	public void A()
	{
		System.out.println("I am A");
	}

}
