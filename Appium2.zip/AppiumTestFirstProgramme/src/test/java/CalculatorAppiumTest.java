import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class CalculatorAppiumTest {

	static AppiumDriver driver;


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			openCalculator();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getCause());
			System.out.println(e.getMessage());

		}


	}

	public static void openCalculator() throws MalformedURLException
	{
		DesiredCapabilities cp = new DesiredCapabilities();
		cp.setCapability("deviceName", "Galaxy M31 s");
		cp.setCapability("udid", "RZ8N90XMSCP");
		cp.setCapability("platformName", "Android");
		cp.setCapability("platformVersion", "11");

		cp.setCapability("automationName", "UiAutomator2");
		cp.setCapability("appPackage", "com.sec.android.app.popupcalculator");
		cp.setCapability("appActivity", "com.sec.android.app.popupcalculator.Calculator");

		URL url = new URL("http://127.0.0.1:4723/wd/hub");
		driver = new AppiumDriver<MobileElement>(url,cp);

		System.out.println("Application started");


	}

}
