package groupingInTestNG;

import org.testng.annotations.Test;

public class CarLoan {
	@Test  
	public void WebLoginCarLoan()  
	{  
	System.out.println("Web Login car Loan");  
	}  
	@Test(groups= {"RegressionTest"})   
	public void MobileLoginCarLoan()  
	{  
	System.out.println("Mobile Login car Loan");  
	}  
	@Test(groups= {"SmokeTest","RegressionTest"})  
	public void APILoginCarLoan()  
	{  
	System.out.println("API Login car Loan");  
	}

}
