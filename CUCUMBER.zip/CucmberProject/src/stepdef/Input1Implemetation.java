package stepdef;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Input1Implemetation {
	
	@Given("^CD$")
	public void cd() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("CD");
	}

	@When("^EF$")
	public void ef() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		System.out.println("EF");
	}

	@When("^GH$")
	public void gh() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		System.out.println("GH");
	}

	@Then("^IJ$")
	public void ij() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 //   throw new PendingException();
		System.out.println("IJ");
	}

	@When("^MN$")
	public void mn() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	//    throw new PendingException();
		System.out.println("MN");
	}

	@Then("^OP$")
	public void op() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 //   throw new PendingException();
		System.out.println("OP");
	}

}
