package superKeyWord;

public class SuperConstructor1 {
	
	SuperConstructor1()
	{
		System.out.println("super class default constructor");
	}	
	
	SuperConstructor1(int n)
	{
		System.out.println("super class parametrised constructor");
	}

}
