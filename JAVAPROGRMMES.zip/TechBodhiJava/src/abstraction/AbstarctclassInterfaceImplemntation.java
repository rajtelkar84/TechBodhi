package abstraction;

public class AbstarctclassInterfaceImplemntation extends AbstarctclassInterface{

	@Override
	public void B() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void C() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void D() {
		// TODO Auto-generated method stub
		
	}
	
	public static void main(String[] args) {
		
		AbstarctclassInterface a = new AbstarctclassInterfaceImplemntation();
		a.A();
		
	}

}
