package abstraction;

public interface Interface2 {
	
	void A();
	void B();
	void C();
	void D();

}
