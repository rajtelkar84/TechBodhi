package encapsulation;

public class Encapsulation2 {
	
	private String panCard="ABCD1234E";  
	
	
	//getter method for college  
	public String getpanCard(){  
	return panCard;  
	}  

}
