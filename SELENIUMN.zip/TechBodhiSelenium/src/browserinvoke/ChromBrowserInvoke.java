package browserinvoke;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class ChromBrowserInvoke {
	public static void main(String[] args) {
		
		ChromeOptions ch = new ChromeOptions();
		ch.setBinary("C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe");
		
		System.setProperty("webdriver.chrome.driver",
"C:\\Users\\telkaraj\\Desktop\\AllData_18June\\Mydocs\\TechBodhi"
+ "\\File\\Chromedriver\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver(ch);
	    driver.manage().window().maximize();
	    driver.get("https://google.co.in/");
	   // driver.close();
	}

}
