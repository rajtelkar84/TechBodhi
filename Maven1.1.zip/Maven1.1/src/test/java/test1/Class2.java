package test1;

import org.testng.annotations.Test;

public class Class2 {

	@Test
	public void secondest() {
		System.out.println("secondtest");
	}

}
