package testSuite;

import org.testng.annotations.Test;

public class TestSuitClass2 {
	
	@Test
	  public void method3() {
		  System.out.println("Test3");
	  }
	
	@Test
	  public void method4() {
		  System.out.println("Test 4");
	  }

}
