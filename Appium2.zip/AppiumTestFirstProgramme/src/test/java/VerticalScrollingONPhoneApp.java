import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class VerticalScrollingONPhoneApp {
	static AppiumDriver driver;

	public static void main(String[] args) {
		try {
			openPhone();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getCause());
			System.out.println(e.getMessage());
		}
	}
		
		public static void openPhone() throws MalformedURLException
		{
			DesiredCapabilities cp = new DesiredCapabilities();
			cp.setCapability("deviceName", "Galaxy M31 s");
			cp.setCapability("udid", "RZ8N90XMSCP");
			cp.setCapability("platformName", "Android");
			cp.setCapability("platformVersion", "11");

			cp.setCapability("automationName", "UiAutomator2");
			cp.setCapability("appPackage", "com.samsung.android.dialer");
			cp.setCapability("appActivity", "com.samsung.android.dialer.DialtactsActivity");

			URL url = new URL("http://127.0.0.1:4723/wd/hub");
			driver = new AppiumDriver<MobileElement>(url,cp);
             driver.findElementById("android:id/button1").click();
             driver.findElementById("com.samsung.android.dialer:id/calllog_tab_button").click();
             WebElement el = driver.findElement(By.id("com.samsung.android.dialer:id/coordinator_layout"));
             Dimension diemension = driver.manage().window().getSize();
             Dimension diemensionofPhoneScreen = el.getSize();
             int YaxisHalfofPhone = diemensionofPhoneScreen.getHeight()/2;
             int XaxisHalfofPhone = diemensionofPhoneScreen.getWidth()/2;
             
             Double VerticlscrollPOint = diemensionofPhoneScreen.getHeight()*.10;
             int VerticlscrollPOintInt =VerticlscrollPOint.intValue();
             
             
             System.out.println(el.getSize());             
             System.out.println(diemension);
             
             TouchAction ta = new TouchAction(driver);
           
             ta.press(PointOption.point(XaxisHalfofPhone, YaxisHalfofPhone)).
             waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2))).
             moveTo(PointOption.point(XaxisHalfofPhone,VerticlscrollPOintInt)).
             release().perform();
			System.out.println("Phone started");


		}
	

}
