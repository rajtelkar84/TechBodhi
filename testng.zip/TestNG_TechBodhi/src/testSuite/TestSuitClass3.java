package testSuite;

import org.testng.annotations.Test;

public class TestSuitClass3 {
	
	@Test
	  public void method5() {
		  System.out.println("Test 5");
	  }
	
	@Test
	  public void method6() {
		  System.out.println("Test 6");
	  }

}
