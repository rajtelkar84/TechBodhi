package encapsulation;

public class Encapsulation3 {
	
	//private data member  
	private String college;  
	//getter method for college  
	public void setCollege(String college){  
	this.college=college;  
	}  

}
