package conditionalStatment;

public class ForEachExample {
	

public static void main(String[] args) {
	
	int arr[] = {12,15,65,1,98,54};
	
	for(int a:arr) {
	
	System.out.println(a);
}

}

}
