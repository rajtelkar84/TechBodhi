package abstraction;

public abstract class ReserveBank {
	
	abstract int getRateOfIntrest();
	

}
