package finalKeyword;

public class FinalMethod {
	
	final void notchangable()
	{
		System.out.println("I can not change");
	}
	
	

}
