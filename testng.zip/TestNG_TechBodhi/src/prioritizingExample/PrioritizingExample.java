package prioritizingExample;

import org.testng.annotations.Test;

public class PrioritizingExample {
	
	@Test(priority = 1,enabled=false)
	public void FirstTest()
	{
		System.out.println("Test1");
	}
	@Test(priority = 2)
	public void secondTest()
	{
		System.out.println("Test 2");
	}
	@Test(priority = 3)
	public void ThirdTest()
	{
		System.out.println("Test 3");
	}
	@Test(priority = 4)
	public void FourthTest()
	{
		System.out.println("Test 4");
	}

}
