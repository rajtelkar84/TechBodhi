import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class DragAndDrop {
	
	static AppiumDriver driver;


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			openDragAndDrop();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.findElement(By.id("dragdrop.stufflex.com.dragdrop:id/btn_literature")).click();
			
			WebElement dragElement = driver.findElement(By.id("dragdrop.stufflex.com.dragdrop:id/chooseA"));
			WebElement dropElement = driver.findElement(By.id("dragdrop.stufflex.com.dragdrop:id/answer"));
			
			int middeleofXcordinate_DragELemen=dragElement.getLocation().x + (dragElement.getSize().width/2);
			int middeleofYcordinate_DragELemen=dragElement.getLocation().y + (dragElement.getSize().height/2);
			
			int middeleofXcordinate_DropELemen=dropElement.getLocation().x + (dropElement.getSize().width/2);
			int middeleofYcordinate_DropELemen=dropElement.getLocation().y + (dropElement.getSize().height/2);
			
			TouchAction th = new TouchAction(driver);
			th.longPress(PointOption.point(middeleofXcordinate_DragELemen, middeleofYcordinate_DragELemen)).
			waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2))).
			moveTo(PointOption.point(middeleofXcordinate_DropELemen,middeleofYcordinate_DropELemen)).
			release().perform();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getCause());
			System.out.println(e.getMessage());

		}


	}

	public static void openDragAndDrop() throws MalformedURLException
	{
		DesiredCapabilities cp = new DesiredCapabilities();
		cp.setCapability("deviceName", "Galaxy M31 s");
		cp.setCapability("udid", "RZ8N90XMSCP");
		cp.setCapability("platformName", "Android");
		cp.setCapability("platformVersion", "11");

		cp.setCapability("automationName", "UiAutomator2");
		cp.setCapability("appPackage", "dragdrop.stufflex.com.dragdrop");
		cp.setCapability("appActivity", "dragdrop.stufflex.com.dragdrop.splash");

		URL url = new URL("http://127.0.0.1:4723/wd/hub");
		driver = new AppiumDriver<MobileElement>(url,cp);

		System.out.println("Application started");


	}


}
