package encapsulation;

public class Encapsulation2Implemtation {
	
	
	public static void main(String[] args) {
		
		Encapsulation2 en = new Encapsulation2();
		System.out.println(en.getpanCard());
	}

}
