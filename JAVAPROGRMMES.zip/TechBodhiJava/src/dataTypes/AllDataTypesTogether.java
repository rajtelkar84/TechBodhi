package dataTypes;

public class AllDataTypesTogether {
	
	public static void main(String[] args) {
		
	
	
	char a = 'R';
	
	int i =88 ;
	
	byte b = 4;
	
	short s = 56;
	
	double d = 4.355453532;
	
	float f = 4.7333434f;
	
	System.out.println("char: " + a);
    System.out.println("integer: " + i);
    System.out.println("byte: " + b);
    System.out.println("short: " + s);
    System.out.println("float: " + f);
    System.out.println("double: " + d);

}
}
