package encapsulation;

public class Enacapsulation1 {
	
	private String Name;
	
	//getter method for name  
	public String getName(){  
	return Name;  
	}  
	//setter method for name  
	public void setName(String Name){  
	this.Name=Name ;
	}  

}
