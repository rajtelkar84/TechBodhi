package abstraction;

public abstract class AbstractClass1 {
	
	public abstract void abstarctmethod1();

	
	public void simplemethod()
	{
		System.out.println("This is simplemethod");
	}

}
