package finalKeyword;

/*public class FinalClassImplementation extends FinalClass {

}
*/

