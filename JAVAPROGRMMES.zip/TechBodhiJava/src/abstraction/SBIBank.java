package abstraction;

public class SBIBank extends ReserveBank {

	@Override
	int getRateOfIntrest() {
		// TODO Auto-generated method stub
		return 4;
	}
	
	

}
