package parllelTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class ParllelTesting {
	
	public WebDriver driver;
    @Test
    public void FirefoxTest() {	 
        //Initializing the firefox driver (Gecko)
    	System.setProperty("webdriver.gecko.driver","C:\\Users\\telkaraj\\Desktop\\AllData_18June\\Mydocs\\TechBodhi\\File\\Geckodriver\\geckodriver-v0.21.0-win64\\geckodriver.exe");
    driver = new FirefoxDriver();	  
    driver.get("https://www.google.co.in"); 
    System.out.println(driver.getCurrentUrl());
    driver.quit();
     }

    @Test
	public void ChromeTest()
	{ 
  //Initialize the chrome driver
  System.setProperty("webdriver.chrome.driver", "C:\\Users\\telkaraj\\Desktop\\AllData_18June\\Mydocs\\TechBodhi\\File\\Chromedriver\\chromedriver_win32\\chromedriver.exe");
  driver = new ChromeDriver();
  driver.get("https://www.google.co.in"); 
  driver.getCurrentUrl();
  driver.quit();
	}

}
