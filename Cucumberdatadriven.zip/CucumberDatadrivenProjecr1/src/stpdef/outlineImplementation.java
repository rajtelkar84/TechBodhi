package stpdef;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class outlineImplementation {
	@Given("^I open google$")
	public void i_open_google() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		System.out.println("opened google");
	}

	@When("^I enter \"(.*?)\" in search textbox$")
	public void i_enter_in_search_textbox(String number) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		System.out.println(number);
	}

	@Then("^I should get result as \"(.*?)\"$")
	public void i_should_get_result_as(String result) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 //   throw new PendingException();
		System.out.println(result);
	}


}
